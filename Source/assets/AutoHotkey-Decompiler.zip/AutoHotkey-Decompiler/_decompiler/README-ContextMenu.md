# AutoHotkey Decompiler - Context Menu Version

## Overview
This is an enhanced version of the AutoHotkey Decompiler that integrates directly into Windows Explorer context menu. Simply right-click any .exe file and select "Decompile AutoHotkey Script" to automatically extract the source code.

**Note:** This new version is located in the `_decompiler` subfolder to keep it separate from the legacy manual batch script version (which outputs to the `decompiled\` folder in the parent directory).

### What's New
- **One-click decompilation** - Right-click context menu integration
- **Automatic file naming** - No manual input required
- **Works anywhere** - Decompile files from any location
- **Output in same folder** - Decompiled .ahk file appears next to the .exe
- **No admin rights needed** - Uses HKEY_CURRENT_USER registry
- **Visual feedback** - Windows notifications for success/errors
- **Separate from legacy version** - Uses `_decompiler\logs\` instead of parent `logs\`

---

## Installation

### Step 1: Compile the Decompiler
1. Right-click on `Decompiler.ahk`
2. Select **"Compile Script"**
3. Wait for `Decompiler.exe` to be created

> **Note:** You need AutoHotkey v1.1+ installed to compile scripts. Download from https://www.autohotkey.com

### Step 2: Install Context Menu
1. Double-click `Install-ContextMenu.ahk`
2. Click **OK** on the success message

**That's it!** No administrator privileges required.

---

## Usage

### Decompiling an AutoHotkey Executable
1. **Right-click** any `.exe` file in Windows Explorer
2. Select **"Decompile AutoHotkey Script"** from the context menu
3. Wait a few seconds
4. A notification will appear: "AutoHotkey Decompiled: filename_decompiled.ahk"
5. The decompiled `.ahk` file will be in the **same folder** as the .exe

### Example
```
Input:  C:\MyPrograms\MyScript.exe
Output: C:\MyPrograms\MyScript_decompiled.ahk
Log:    [AutoHotkey-Decompiler folder]\_decompiler\logs\MyScript_decompile_20250118_143052.log
```

---

## How It Works

1. **Validation**: Checks if the file exists and is an .exe
2. **Extraction**: Uses ResourceHacker to extract RCDATA from the executable
3. **Conversion**: Converts the binary data to .ahk format
4. **Cleanup**: Removes temporary files automatically
5. **Notification**: Shows success or error message

---

## Requirements

- **Windows**: XP or later
- **AutoHotkey**: v1.1+ (only for compiling, not required for using the compiled .exe)
- **Permissions**: Normal user (no admin rights needed)

### Included Tools
- `..\library\ResourceHacker.exe` - Extracts resources from executables (in parent folder)
- All other dependencies are included

### Folder Structure
```
AutoHotkey-Decompiler-v2.97.00C\
├── _decompiler\               [NEW CONTEXT MENU VERSION]
│   ├── Decompiler.ahk        (compile this to Decompiler.exe)
│   ├── Decompiler.exe        (compiled executable)
│   ├── Install-ContextMenu.ahk
│   ├── Uninstall-ContextMenu.ahk
│   ├── README-ContextMenu.md
│   └── logs\                 (created automatically)
├── library\                  [SHARED RESOURCES]
│   └── ResourceHacker.exe
├── decompiled\               [OLD MANUAL VERSION OUTPUT]
├── logs\                     [OLD MANUAL VERSION LOGS]
├── 0_initialize_decompile.bat  [OLD MANUAL VERSION]
└── 1_finalize.cmd              [OLD MANUAL VERSION]
```

---

## Uninstallation

### Remove Context Menu
1. Double-click `Uninstall-ContextMenu.ahk`
2. Click **OK** on the confirmation message

The context menu entry will be removed immediately. The decompiler files remain on your system and can be deleted manually if desired.

---

## Troubleshooting

### "Decompiler.exe not found"
**Solution:** You need to compile `Decompiler.ahk` first.
1. Right-click `Decompiler.ahk`
2. Select "Compile Script"

### "Not an AutoHotkey executable"
**Cause:** The .exe file you're trying to decompile is not a compiled AutoHotkey script.
**Solution:** This decompiler only works with AutoHotkey executables that contain RCDATA resources.

### "Failed to extract script data"
**Possible causes:**
- The executable is protected/encrypted
- The executable is corrupted
- Not enough disk space

### Context menu doesn't appear
**Solutions:**
1. Run `Install-ContextMenu.ahk` again
2. Restart Windows Explorer (Task Manager → Restart "Windows Explorer")
3. Check Registry Editor: `HKEY_CURRENT_USER\Software\Classes\exefile\shell\DecompileAHK`

---

## Technical Details

### Registry Location
```
HKEY_CURRENT_USER\Software\Classes\exefile\shell\DecompileAHK
```

This location is user-specific and does not require administrator privileges.

### File Locations
- **Decompiled scripts**: Same folder as the original .exe
- **Logs**: `_decompiler\logs\` (in the _decompiler subfolder)
- **Temporary files**: Automatically cleaned up after each run (in _decompiler folder)

### Supported AutoHotkey Versions
This decompiler works with compiled scripts from:
- AutoHotkey v1.0.x
- AutoHotkey v1.1.x

---

## Legacy Batch Script Version

The old manual batch scripts are still available:
- `0_initialize_decompile.bat` - Start decompilation (manual)
- `1_finalize.cmd` - Finalization step (automatic)

However, the new context menu version is recommended for ease of use.

---

## License & Credits

### AutoHotkey Decompiler
- **Version**: 2.97.00C
- **Author**: Jake (A-gent)
- **Released**: March 17, 2020
- **Context Menu Enhancement**: January 2025

### ResourceHacker
- **Version**: 4.5.28
- **Author**: Angus Johnson
- **License**: Freeware for personal use
- **Website**: http://www.angusj.com/resourcehacker/

---

## Frequently Asked Questions

**Q: Does this work on protected/obfuscated executables?**
A: No, this decompiler only works on standard compiled AutoHotkey scripts that have not been protected or obfuscated.

**Q: Can I batch-decompile multiple files?**
A: Currently, you need to right-click each file individually. Batch support may be added in a future version.

**Q: Will this affect other users on my computer?**
A: No, the context menu is installed per-user using HKEY_CURRENT_USER.

**Q: Can I change the output filename?**
A: The current version automatically names files as `[original]_decompiled.ahk`. Custom naming may be added in future versions.

**Q: Is the source code of the decompiled script identical to the original?**
A: In most cases, yes. However, comments and whitespace formatting may differ from the original source.

---

## Support & Feedback

For issues, questions, or suggestions, please refer to the AutoHotkey community forums or the decompiler's repository.

---

**Enjoy one-click AutoHotkey decompilation!**
