     _____   ___      ______  ___  ____   ______  _________ _______         _      _______   
    |_   _|.'   `.  .' ___  ||_  ||_  _|.' ____ \|  _   _  |_   __ \       / \    |_   __ \  
      | | /  .-.  \/ .'   \_|  | |_/ /  | (___ \_|_/ | | \_| | |__) |     / _ \     | |__) | 
  _   | | | |   | || |         |  __'.   _.____`.    | |     |  __ /     / ___ \    |  ___/  
 | |__' | \  `-'  /\ `.___.'\ _| |  \ \_| \____) |  _| |_   _| |  \ \_ _/ /   \ \_ _| |_     
 `.____.'  `.___.'  `.____ .'|____||____|\______.' |_____| |____| |___|____| |____|_____|    
                                                 
        _______ _______ _______       
       |\     /|\     /|\     /|      ___  ___ ___ ___  __  __ ___ ___ _    ___ ___ 
       | +---+ | +---+ | +---+ |     |   \| __/ __/ _ \|  \/  | _ |_ _| |  | __| _ \
       | |   | | |   | | |   | |     | |) | _| (_| (_) | |\/| |  _/| || |__| _||   /
       | |A  | | |H  | | |K  | |     |___/|___\___\___/|_|  |_|_| |___|____|___|_|_\
       | +---+ | +---+ | +---+ |    _________________________________________________
       |/_____\|/_____\|/_____\|      
                                                   
                                                                   
 _______________________________________________________________________________________________________________

    .-..-..-..---.  .--. 
    : :: `: :: .--': ,. :
    : :: .` :: `;  : :: :
    : :: :. :: :   : :; :
    :_;:_;:_;:_;   `.__.'
                         
-  BUILD:  RELEASE
-  VERSION:  2.97.00C
-  DRAFT DATE:  3-17-2020
-  DESCRIPTION:  Batch-based decompiler system for any version of compiled .exe variant of an AHK script.
 _______________________________________________________________________________________________________________

    .-..-. .--.  .--.  .--.  .--. 
    : :: :: .--': .; :: .--': .--'
    : :: :`. `. :    :: : _ : `;  
    : :; : _`, :: :: :: :; :: :__ 
    `.__.'`.__.':_;:_;`.__.'`.__.'
                                  
-  TO USE:  Place the desired compiled AutoHotkey Script (.exe) inside of the root folder alongside the
           "0_initialize_decompile.bat" and "1_finalize.cmd" and then run the "0_initialize_decompile.bat".
            Then follow the on-screen instructions to decompile the target AutoHotkey Script.
            
            Upon completion of decompilation, the newly decompiled script will be found inside of the
            "decompiled" folder.
            
            
            The given compiled AHK script "Dota2_AutoAccepter_AhkExample.exe" serves as an example for testing.

 _______________________________________________________________________________________________________________

    .-----. .--.        .---.  .--. 
    `-. .-': ,. :       : .  :: ,. :
      : :  : :: : _____ : :: :: :: :
      : :  : :; ::_____:: :; :: :; :
      :_;  `.__.'       :___.'`.__.'
                                    
                                    
-  Add a hardcoded executable that will automatically parse all .exe files inside of the root directory and
    dynamically pipe them to the decompiler without the need for user input, allowing for both automated
    (with the exectuable) and targeted (with the "0_initialize_decompile.bat") decompiling.
 _______________________________________________________________________________________________________________


